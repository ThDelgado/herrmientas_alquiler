CUE: SENTENCIAS DDL A PARTIR DE MODELO FÍSICO 
DRILLING: ARRIENDO DE HERRAMIENTAS 

evaluacion

m5s4

para clonar:
https://github.com/ThDelgado/herrmientas_alquiler.git

Thelma Delgado